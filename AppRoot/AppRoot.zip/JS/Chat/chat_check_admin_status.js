// $(document).ready(function() {
//
//     setInterval(function() {
//         $.ajax({
//             url: 'Controllers/Chat/getAdminStatus.php',
//             method: 'GET',
//             success: function(result) {
//                 document.getElementById("status").innerHTML = result;
//             }
//         });
//     }, 1000);
// });
